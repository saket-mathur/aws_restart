myFinalAnswerTuple=("apple","banana","pineapple")
print(myFinalAnswerTuple)
print(typ)